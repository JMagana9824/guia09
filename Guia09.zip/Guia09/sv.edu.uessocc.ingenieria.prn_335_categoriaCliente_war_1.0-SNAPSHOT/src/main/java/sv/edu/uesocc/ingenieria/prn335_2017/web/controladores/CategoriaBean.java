/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.controladores;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.primefaces.event.SelectEvent;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Categoria;
import sv.edu.uesocc.ingenieria.prn335_2017.web.rest.categoriaClient;

/**Declaracion de ManagedBean 
* @author jacque
* 
 */

@Named
@ViewScoped
public class CategoriaBean extends categoriaClient implements Serializable {

   public CategoriaBean() {
    }
    
    boolean activo,visible=true,ver=false;

    public boolean isVisible() {
        return visible;
    }

    public boolean isVer() {
        return ver;
    }

    public void setVer(boolean ver) {
        this.ver = ver;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    /**
     * inyeccciones EJB
     */
    
    Categoria catEntity;
    List lista = getSalida();
    List<Categoria> filtroCat= new ArrayList<>();
    
    
    public void limpiar(){
        catEntity.setIdCategoria(null);
        catEntity.setNombre(null);
        catEntity.setActivo(false);
        catEntity.setDescripcion(null);
    }
    
    
/**metodo para seleccionar componentes de mi tabla
 * selecion  d objetos
 * @param event 
 */
     public void onRowSelect(SelectEvent event) {
       catEntity = (Categoria) event.getObject();
        visible=false;
        ver=true;
     }
  
  
     public void cancelar(){
         catEntity= new Categoria();
       visible=true;
         ver=false;
        
     }
     
    public void nuevo(){
      catEntity= new Categoria();
    visible=true;
    ver=true;
        
    }
     
     
    public List<Categoria> getFiltroCat() {
        return filtroCat;
    }
    public void setFiltroCat(List<Categoria> filtroCat) {
        this.filtroCat = filtroCat;
    }
    
    Categoria selectedCat;

    public Categoria getSelectedCat() {
        return selectedCat;
    }

    public void setSelectedCat(Categoria selectedCat) {
        this.selectedCat = selectedCat;
    }
  
    @PostConstruct
    public void init(){
     findAll();
    }
    
   
public boolean isActivo() {
        return activo;
    }

    

    public Categoria getCatEntity() {
        return catEntity;
    }

    public void setCatEntity(Categoria catEntity) {
        this.catEntity = catEntity;
    }

   

    public List<Categoria> getLista() {
        return lista;
    }

    public void setLista(List<Categoria> lista) {
        this.lista = lista;
    }
  
}
